Verwendung mxtestbench.exe

Um die AUTOLIV-Applikation mxtestbench.exe verwenden zu k�nnen muss zuk�nftig die Qt-Version 4.8.7 installiert werden.
Vorher muss sichergestllt werden das �ltere Qt-Versionen sicher vom Arbeitsrechner deinstalliert wurden.
Ansonsten greift das Windows-System immer auf die �lteren Versionen zu und dies verursacht Windows-Fehler wie
 - mxtestbench.exe - Einsprungpunkt nicht gefunden - .


Link zur ben�tigten Qt-Version:
https://download.qt.io/official_releases/qt/4.8/4.8.7/qt-opensource-windows-x86-vs2010-4.8.7.exe 

Nach der Installation kann es n�tig werden die Windows-Systemvariablen anzupassen.

Wichtige DLL's sind:
QtCore4.dll
QtCored4.dll
QtGui4.dll
QtGuid4.dll